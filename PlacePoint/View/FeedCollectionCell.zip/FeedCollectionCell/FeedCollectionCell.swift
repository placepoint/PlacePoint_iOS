//
//  FeedCollectionCell.swift
//  PlacePoint
//
//  Created by Mac on 06/06/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit
import Kingfisher

class FeedCollectionCell: UICollectionViewCell {
   
    @IBOutlet weak var imagesCollections: UIImageView!

    //MARK: Life Cycle
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        imagesCollections.image = nil
        // reset custom properties to default values
    }
    
    func setData(url: String) {
        
         let strUrl = url
        
        if strUrl != "" {
            
            let url = URL(string: strUrl)!
            
            self.imagesCollections.kf.indicatorType = .activity
            
            (self.imagesCollections.kf.indicator?.view as? UIActivityIndicatorView)?.color = .gray
            
            self.imagesCollections.kf.setImage(with: url,
                                               placeholder: #imageLiteral(resourceName: "placeholder-1"),
                                               options: [.transition(ImageTransition.fade(1))],
                                               progressBlock: { receivedSize, totalSize in
            },
                                               completionHandler: { image, error, cacheType, imageURL in
            })
            
        }
        
        
    }

}
