//
//  Extension+BusinessDetailVC.swift
//  PlacePoint
//
//  Created by Mac on 19/06/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import Foundation
import UIKit

//MARK: TableView DataSource and Delegate

extension BusinessDetailVC: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "AboutPubCell", for: indexPath) as? AboutPubCell else{
                fatalError()
            }
            
            cell.lblDetails.text = dictBusinessDetails.value(forKey: "description") as? String
            
            
            cell.selectionStyle = .none
            
            cell.imgArray = dictBusinessDetails.value(forKey: "image_url") as! [AnyObject]
            
            return cell
        } else {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "OpeningDetailsCell", for: indexPath) as? OpeningDetailsCell else{
                fatalError()
            }
            
            cell.selectionStyle = .none
            
            if  arrOpeningHrs.count > 0{
                
                
                if ((arrOpeningHrs[0] as AnyObject).value(forKey: "startFrom")as! String) == "" || ((arrOpeningHrs[0] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[0] as AnyObject).value(forKey: "startTo")as! String) == "closed" {
                    
                    cell.lblMonStartTime.text = "closed"
                }
                else {
                    
                    cell.lblMonStartTime.text = ((arrOpeningHrs[0] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[0] as AnyObject).value(forKey: "startTo")as! String)
                }
                
                if ((arrOpeningHrs[1] as AnyObject).value(forKey: "startFrom")as! String) == "" && ((arrOpeningHrs[1] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[1] as AnyObject).value(forKey: "startTo")as! String) == "closed"{
                    
                    cell.lblTuesStartTime.text = "closed"
                }
                else{
                    cell.lblTuesStartTime.text = ((arrOpeningHrs[1] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[1] as AnyObject).value(forKey: "startTo")as! String)
                }
                
                if ((arrOpeningHrs[2] as AnyObject).value(forKey: "startFrom")as! String) == "" && ((arrOpeningHrs[2] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[2] as AnyObject).value(forKey: "startTo")as! String) == "closed"{
                    
                    cell.lblWedStartTime.text = "closed"
                }
                else{
                    cell.lblWedStartTime.text = ((arrOpeningHrs[2] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[2] as AnyObject).value(forKey: "startTo")as! String)
                }
                if ((arrOpeningHrs[3] as AnyObject).value(forKey: "startFrom")as! String) == "" && ((arrOpeningHrs[3] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[3] as AnyObject).value(forKey: "startTo")as! String) == "closed"{
                    
                    cell.lblThursStartTime.text = "closed"
                }
                else{
                    cell.lblThursStartTime.text = ((arrOpeningHrs[3] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[3] as AnyObject).value(forKey: "startTo")as! String)
                }
                
                if ((arrOpeningHrs[4] as AnyObject).value(forKey: "startFrom")as! String) == "" && ((arrOpeningHrs[4] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[4] as AnyObject).value(forKey: "startTo")as! String) == "closed"{
                    
                    cell.lblFriStartTime.text = "closed"
                }
                else{
                    
                    cell.lblFriStartTime.text = ((arrOpeningHrs[4] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[4] as AnyObject).value(forKey: "startTo")as! String)
                }
                
                if ((arrOpeningHrs[5] as AnyObject).value(forKey: "startFrom")as! String) == "" && ((arrOpeningHrs[5] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[5] as AnyObject).value(forKey: "startTo")as! String) == "closed"{
                    
                    cell.lblSatStartTime.text = "closed"
                }
                else{
                    cell.lblSatStartTime.text = ((arrOpeningHrs[5] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[5] as AnyObject).value(forKey: "startTo")as! String)
                }
                
                if ((arrOpeningHrs[6] as AnyObject).value(forKey: "startFrom")as! String) == "" && ((arrOpeningHrs[6] as AnyObject).value(forKey: "startTo")as! String) == "" || ((arrOpeningHrs[6] as AnyObject).value(forKey: "startTo")as! String) == "closed"{
                    
                    cell.lblSunStartTime.text = "closed"
                }
                else{
                    cell.lblSunStartTime.text = ((arrOpeningHrs[6] as AnyObject).value(forKey: "startFrom")as! String)+"-"+((arrOpeningHrs[6] as AnyObject).value(forKey: "startTo")as! String)
                }
                
                
                if ((arrOpeningHrs[0] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[0] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblMonCloseTime.text = "closed"
                }
                else if ((arrOpeningHrs[0] as AnyObject).value(forKey: "closeFrom")as! String) == "" || ((arrOpeningHrs[0] as AnyObject).value(forKey: "closeTo")as! String) == ""{
                    
                    cell.lblMonCloseTime.text = "00AM-00PM"
                }
                else {
                    
                    cell.lblMonCloseTime.text = ((arrOpeningHrs[0] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[0] as AnyObject).value(forKey: "closeTo")as! String)
                }
                
                if ((arrOpeningHrs[1] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[1] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblTuesCloseTime.text = "closed"
                }
                else if ((arrOpeningHrs[1] as AnyObject).value(forKey: "closeFrom")as! String) == "" && ((arrOpeningHrs[1] as AnyObject).value(forKey: "closeTo")as! String) == "" || ((arrOpeningHrs[1] as AnyObject).value(forKey: "closeTo")as! String) == "closed"{
                    
                    cell.lblTuesCloseTime.text = "00AM-00PM"
                }
                else{
                    cell.lblTuesCloseTime.text = ((arrOpeningHrs[1] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[1] as AnyObject).value(forKey: "closeTo")as! String)
                }
                
                
                if ((arrOpeningHrs[2] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[2] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblWedCloseTime.text = "closed"
                }
                else if ((arrOpeningHrs[2] as AnyObject).value(forKey: "closeFrom")as! String) == "" && ((arrOpeningHrs[2] as AnyObject).value(forKey: "closeTo")as! String) == "" || ((arrOpeningHrs[2] as AnyObject).value(forKey: "closeTo")as! String) == "closed"{
                    
                    cell.lblWedCloseTime.text = "00AM-00PM"
                }
                else{
                    cell.lblWedCloseTime.text = ((arrOpeningHrs[2] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[2] as AnyObject).value(forKey: "closeTo")as! String)
                }
                
                
                if ((arrOpeningHrs[3] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[3] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblThursCloseTime.text = "closed"
                }
                else  if ((arrOpeningHrs[3] as AnyObject).value(forKey: "closeFrom")as! String) == "" && ((arrOpeningHrs[3] as AnyObject).value(forKey: "closeTo")as! String) == "" || ((arrOpeningHrs[3] as AnyObject).value(forKey: "closeTo")as! String) == "closed"{
                    
                    cell.lblThursCloseTime.text = "00AM-00PM"
                }
                else{
                    cell.lblThursCloseTime.text = ((arrOpeningHrs[3] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[3] as AnyObject).value(forKey: "closeTo")as! String)
                }
                
                
                if ((arrOpeningHrs[4] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[4] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblFriCloseTime.text = "closed"
                }
                else if ((arrOpeningHrs[4] as AnyObject).value(forKey: "closeFrom")as! String) == "" && ((arrOpeningHrs[4] as AnyObject).value(forKey: "closeTo")as! String) == "" || ((arrOpeningHrs[4] as AnyObject).value(forKey: "closeTo")as! String) == "closed"{
                    
                    cell.lblFriCloseTime.text = "00AM-00PM"
                }
                else{
                    
                    cell.lblFriCloseTime.text = ((arrOpeningHrs[4] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[4] as AnyObject).value(forKey: "closeTo")as! String)
                }
                
                if ((arrOpeningHrs[5] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[5] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblSatCloseTime.text = "closed"
                }
                else if ((arrOpeningHrs[5] as AnyObject).value(forKey: "closeFrom")as! String) == "" && ((arrOpeningHrs[5] as AnyObject).value(forKey: "closeTo")as! String) == "" || ((arrOpeningHrs[5] as AnyObject).value(forKey: "closeTo")as! String) == "closed"{
                    
                    cell.lblSatCloseTime.text = "00AM-00PM"
                }
                else{
                    cell.lblSatCloseTime.text = ((arrOpeningHrs[5] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[5] as AnyObject).value(forKey: "closeTo")as! String)
                }
                
                
                if ((arrOpeningHrs[6] as AnyObject).value(forKey: "closeFrom")as! String) == "closed" || ((arrOpeningHrs[6] as AnyObject).value(forKey: "closeTo")as! String) == "closed" {
                    
                    cell.lblSunCloseTime.text = "closed"
                }
                else if ((arrOpeningHrs[6] as AnyObject).value(forKey: "closeFrom")as! String) == "" && ((arrOpeningHrs[6] as AnyObject).value(forKey: "closeTo")as! String) == "" || ((arrOpeningHrs[6] as AnyObject).value(forKey: "closeTo")as! String) == "closed"{
                    
                    cell.lblSunCloseTime.text = "00AM-00PM"
                }
                else{
                    cell.lblSunCloseTime.text = ((arrOpeningHrs[6] as AnyObject).value(forKey: "closeFrom")as! String)+"-"+((arrOpeningHrs[6] as AnyObject).value(forKey: "closeTo")as! String)
                }
            }
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == 1{
            return 340
        }
        return UITableViewAutomaticDimension
    }
}
//MARK: Adopt Protocol
extension BusinessDetailVC: mapDelegate {
    
    func showMapView() {
        
        let mapVC = MapVC(nibName: "MapVC", bundle: nil)
        
        mapVC.lat = (dictBusinessDetails["lat"] as? NSString)!
        mapVC.long = (dictBusinessDetails["long"] as? NSString)!
        
        self.navigationController?.pushViewController(mapVC, animated: true)
    }
}
