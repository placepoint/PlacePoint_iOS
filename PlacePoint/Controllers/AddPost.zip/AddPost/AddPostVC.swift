//
//  AddPostVC.swift
//  PlacePoint
//
//  Created by Mac on 04/06/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit
import MMDrawerController
import SVProgressHUD
import PhotoCropEditor

class AddPostVC: UIViewController {
    
    @IBOutlet weak var tblViewAddPost: UITableView!
    
    
    var imagePicker = UIImagePickerController()
    
    var isfirstYoutubeSelected: Bool = false
    
    var isImageSend: Bool = false
    
    var croppedImage = UIImage()
    
    var selectedImage = UIImage()
    
    var imageHeight = CGFloat()
    
    var headerView = AddPostHeader()
    
    var arrSelectedCategory = [String]()
    
    var footerView = AddPostFooter()
    
    var imageStatus = String()
    
    var heightOfImageToLoad = CGFloat()
    
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        selectedImage = #imageLiteral(resourceName: "placeholder")
        
        let nib = UINib(nibName: "AddPostViewCell", bundle: nil)
        
        tblViewAddPost.register(nib, forCellReuseIdentifier: "AddPostViewCell")
        
        headerView = (Bundle.main.loadNibNamed("AddPostHeader", owner: nil, options: nil)?[0] as? AddPostHeader)!
        
        footerView = (Bundle.main.loadNibNamed("AddPostFooter", owner: nil, options: nil)?[0] as? AddPostFooter)!
        
        self.tblViewAddPost.tableFooterView = footerView
        
        headerView.delegate = self
        
        headerView.txtView.delegate = self
        
        headerView.txtFieldUrl.delegate = self
        
        self.tblViewAddPost.tableHeaderView = headerView
        
        headerView.vwTextViewBd.layer.borderColor = UIColor.lightGray.cgColor
        
        headerView.vwTextViewBd.layer.borderWidth = 1
        
        headerView.vwTextViewBd.clipsToBounds = true
        
        headerView.vwChooseCategory.layer.borderColor = UIColor.lightGray.cgColor
        
        headerView.vwChooseCategory.layer.borderWidth = 1
        
        headerView.vwtextUrl.layer.borderWidth = 0.5
        
        headerView.vwtextUrl.layer.borderColor = UIColor.black.cgColor
        
        headerView.vwtextUrl.layer.cornerRadius = 5

        tblViewAddPost.estimatedRowHeight = 150
        
        tblViewAddPost.rowHeight = UITableViewAutomaticDimension

    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(true)
        
        if arrSelectedCategory.count != 0 {
            
            let strSelectedCategory = (arrSelectedCategory.map{String($0)}).joined(separator: ",")
            
            headerView.lblChooseCategory.text = strSelectedCategory
        }
        else {
            
             headerView.lblChooseCategory.text = "Choose a category"
        }
        
    }

    // MARK: - Set Navigation
    func setUpNavigation() {
        
        navigationController?.navigationBar.isTranslucent = false
        
        navigationController?.navigationBar.barTintColor = UIColor.themeColor()
        
        navigationController?.navigationBar.tintColor = UIColor.white
        
        navigationItem.navTitle(title: "Add New Post")
        
        let textAttributes = [NSAttributedStringKey.foregroundColor:UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        
        let leftBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "backArrow"),
                                                style: .plain,
                                                target: self,
                                                action: #selector(backButtonTapped))
        
        let rightBarButtonItem = UIBarButtonItem(title: "Post", style: .plain, target: self, action: #selector(self.apiAddPost))
        
        self.navigationItem.leftBarButtonItem = leftBarButtonItem
        
        self.navigationItem.rightBarButtonItem = rightBarButtonItem
    }
    
    
    @objc func backButtonTapped() {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    func openEditor() {
        
        let image = selectedImage
        
        // Use view controller
        let controller = CropViewController()
    
        controller.delegate = self
        
        controller.image = image
        
        controller.toolbarHidden = true
        
        let navController = UINavigationController(rootViewController: controller)
        
        navController.modalPresentationStyle = .custom
        
        present(navController, animated: true, completion: nil)
        
    }
    
    
    //MARK: - Api AddPost
    @objc func apiAddPost() {
        
        SVProgressHUD.show()
        
        self.view.isUserInteractionEnabled = false
        
        self.view.endEditing(true)
        
        let strUrl = headerView.txtFieldUrl.text
        
        let strDesc = headerView.txtView.text as String
        
        if isImageSend == true {
            
            imageStatus = "false"
        }
        
        let dictParams = ["auth_code": UserDefaults.standard.getAuthCode(), "description": strDesc, "type": "", "day": "","time": "", "now_status": "", "video_link": strUrl as Any,"width": self.view.frame.size.width - 30 ,"height": self.imageHeight, "image_status": imageStatus,"title": headerView.lblUserName.text] as? [String: Any]
        
        var image = UIImage()
        
        let indexPath = IndexPath(row: 0, section: 0)
        
        let cell = tblViewAddPost.cellForRow(at: indexPath) as? AddPostViewCell
        
        if cell?.imgThumnail.image == nil {
            
            cell?.imgThumnail.image = #imageLiteral(resourceName: "placeholder")
            
            image = (cell?.imgThumnail.image)!
            
            cell?.imgThumnail.isHidden = true
            
            cell?.btnCross.isHidden = true
       
        }
        else {
            
            image = CommonClass.sharedInstance.compressImage((cell?.imgThumnail.image)!)
        }
        
        FeedManager.sharedInstance.imgPost = image
        
        FeedManager.sharedInstance.dictParams = dictParams!
        
        FeedManager.sharedInstance.addPost(completionHandler: { (dictResponse) in
            
            let strStatus = dictResponse["status"] as? String
            
            if strStatus == "true" {
                
                let msg = dictResponse["msg"] as? String
                
                DispatchQueue.main.async {
                    
                    self.showAlertPostAdded(msg: msg!)
                    
                    SVProgressHUD.dismiss()
                    
                    self.view.isUserInteractionEnabled = true
                    
                }
            }
            else if strStatus == "false" {
                
                let msg = dictResponse["msg"] as? String
                
                DispatchQueue.main.async {
                    
                    self.showAlertPostAdded(msg: msg!)
                    
                    SVProgressHUD.dismiss()
                    
                    self.view.isUserInteractionEnabled = true
                }
            }
            
        }, failure: { (error) in
            print(error)
        })
        
    }
    
    
    //MARK: Show Alert of post Added
    func showAlertPostAdded(msg: String) {
        
        let alert = UIAlertController(title: "",message:msg ,preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "ok", style: .default, handler: { (action) in
            self.navigationController?.popViewController(animated:  true)
            
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    //MARKL Keyboard Notification
    func keyBoardNotify() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
}


//MARK: - UITableView DataSource and Delegate
extension AddPostVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if selectedImage == #imageLiteral(resourceName: "placeholder") {
            
            return 0
        }
        else {
            return 1
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AddPostViewCell", for: indexPath) as? AddPostViewCell else {
            fatalError()
        }
        
        cell.selectionStyle = .none
        
        cell.btnCross.isHidden = true
        
        if self.imageHeight != 0.0 {
            
            cell.imgThumnail.isHidden = false

            let getImgViewHeight = cell.imgThumnail.frame.size.height

            let getImgViewWidth = cell.imgThumnail.frame.size.width
            

            let image = resizeImage(image: croppedImage, targetSize: CGSize(width: getImgViewWidth, height: getImgViewHeight))
        
            let ratio = image.size.width / image.size.height
            
            let newHeight = cell.imgThumnail.frame.width / ratio
            
            cell.heightContraintImgThumb.constant = newHeight
            
            self.imageHeight = newHeight
            
            view.layoutIfNeeded()
            
            cell.imgThumnail.image = image
        
            cell.btnCross.isHidden = false
            
            cell.delegate = self
            
            if cell.imgThumnail.image != nil {
            
                imageStatus = "true"
            }
            else {
            
                imageStatus = "false"
            }
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        
        let size = image.size
        
        let widthRatio  = targetSize.width
        let heightRatio = targetSize.height / image.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, UIScreen.main.scale)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
}


//MARK: - AdoptProtocol
extension AddPostVC: OpenImageProtocol {
    
    func chooseCategory() {
        
        let selectCat = SelectCategories(nibName: "SelectCategories", bundle: nil)
        
        selectCat.delegate = self as SelectedCategories
        
        selectCat.isPostVc = true
        
        let nav = UINavigationController(rootViewController: selectCat)
        
        self.navigationController?.present(nav, animated: true, completion: nil)
    }
    
    
    func openCamera() {
        
        if isfirstYoutubeSelected == true {
            
            headerView.vwtextUrl.isHidden = false
            
            headerView.txtFieldUrl.isHidden = false
            
        }
        
        imagePicker.delegate = self
        
        imagePicker.sourceType = .camera
        
        imagePicker.allowsEditing = false
        
        imagePicker.modalPresentationStyle = .custom
        
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    
    func openPhotoLibrary() {
        
        if isfirstYoutubeSelected == true {
            
            headerView.vwtextUrl.isHidden = false
            
            headerView.txtFieldUrl.isHidden = false
        }
        
        imagePicker.delegate = self
        
        imagePicker.sourceType = .photoLibrary
        
        imagePicker.allowsEditing = false
        
        imagePicker.modalPresentationStyle = .custom
        
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    
    func addYouTubeLink() {
        
        self.isfirstYoutubeSelected = true
        
        headerView.vwtextUrl.isHidden = false

        headerView.txtFieldUrl.isHidden = false
        
    }
    
    
}


extension AddPostVC: DeleteImage {
    
    func deleteImage() {
        
        self.imageHeight = 0.0
        
        self.heightOfImageToLoad = 0.0
        
        selectedImage = UIImage()
        
        croppedImage = UIImage()
        
        let indexPath = IndexPath(row: 0, section: 0)
        
        let cell = tblViewAddPost.cellForRow(at: indexPath) as? AddPostViewCell
        
        cell?.imgThumnail.frame.size.height = 0.0
        
        cell?.imgThumnail.image = nil
    
        cell?.imgThumnail.isHidden = true
        
        isImageSend = true
        
        cell?.btnCross.isHidden = true
        
         cell?.btnCross.layer.zPosition = 1
        
    }
}
