//
//  AddPostFooter.swift
//  PlacePoint
//
//  Created by Mac on 20/07/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class AddPostFooter: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
